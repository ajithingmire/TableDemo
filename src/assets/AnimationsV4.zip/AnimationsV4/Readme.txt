1. Install Node.js >= V5.6
2. cd to path/to/AnimationsV4 from your command line.
3. Run "npm install" to install all dependencies.
4. Run "npm run buildall" to build the application.
5. Run "npm run server" to run the web server and services.
6. Application can be access at http://localhost:3000/ or http://yourip:3000/

Commands:
======================
1. npm run buildall: To build the whole application including svg conversion.
2. npm run build: To build app (JavaScript, CSS, HTML).
3. npm run server: To run the server without debug mode.
4. npm run server-debug: To run server with debug mode.