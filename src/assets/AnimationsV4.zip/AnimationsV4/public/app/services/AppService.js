angular.module('animApp').
  service('AppService', function($http) {
    this.getRegions = function() {
      return $http.get('/api/regions');
    };
  });