angular.module('animApp').
  service('GMapService', function($interval, $q) {
		/** @constructor */
		function GMarker(options, labelContent) {
			var marker_ = new google.maps.Marker(options);
			
			// Define a property to hold the image's div. We'll
			// actually create this div upon receipt of the onAdd()
			// method so we'll leave it null for now.
			var div_ = null;
			
			this.setMap(marker_.getMap());
			
			this.getMarker = function() {
				return marker_;
			};

			this.getContainer = function() {
				return div_;
			};

			/**
			 * onAdd is called when the map's panes are ready and the overlay has been
			 * added to the map.
			 */
			this.onAdd = function() {
				div_ = $('<div/>').
				css({
					border: 'none',
					position: 'absolute'
				}).
				append(labelContent);

				// Add the element to the "overlayLayer" pane.
				var panes = this.getPanes();
				$(panes.overlayLayer).append(div_);
			};

			this.draw = function() {
				// We use the south-west and north-east
				// coordinates of the overlay to peg it to the correct position and size.
				// To do this, we need to retrieve the projection from the overlay.
				var overlayProjection = this.getProjection();

				// Retrieve the south-west and north-east coordinates of this overlay
				// in LatLngs and convert them to pixel coordinates.
				// We'll use these coordinates to resize the div.
				var pos = overlayProjection.fromLatLngToDivPixel(marker_.getPosition());

				// Resize the image's div to fit the indicated dimensions.
				div_.css({
					left: (pos.x + 10) + 'px',
					top: (pos.y - (div_.outerHeight() / 2)) + 'px'//,
					//width: '100%'
				});
				
				google.maps.event.trigger(this, 'gmarker_loaded', div_);
			};

			// The onRemove() method will be called automatically from the API if
			// we ever set the overlay's map property to 'null'.
			this.onRemove = function() {
				if (div_ !== null) {
					div_.remove();
					div_ = null;
				}
			};
			
			this.remove = function() {
				this.setMap(null);
				marker_.setMap(null);
			};
		}
		GMarker.prototype = new google.maps.OverlayView();
		this.GMarker = GMarker;

		function ArcPath(pointStart, pointEnd, options, animationCompleted) {
			var plotPoints = [],
					line = null, animObj = null;
			options = $.extend({}, {
				straightLength: 5,
				startPointOffset: new google.maps.Point(0, 0),
				endPointOffset: new google.maps.Point(0, 0),
				attr: {}
			}, options);

			pointStart = new google.maps.LatLng(pointStart.lat() , pointStart.lng());
			pointEnd = new google.maps.LatLng(pointEnd.lat() + options.endPointOffset.y, pointEnd.lng() + options.endPointOffset.x);

			function arcPoints(center, radius, flag) {
				// radians
				var angl = 180;
				var d = radius / 3963.189;
				// radians
				var lat = (Math.PI / angl) * center.lat();
				// radians
				var lng = (Math.PI / angl) * center.lng();

				for (var a = - (angl + 1); a < 0; a++) {
					var tc = (Math.PI / angl) * a;
					var y;
					if (flag) {
						y = Math.asin(Math.sin(lat) * Math.cos(d) - Math.cos(lat) * Math.sin(d) * Math.cos(tc));
					}
					else {
						y = Math.asin(Math.sin(lat) * Math.cos(d) + Math.cos(lat) * Math.sin(d) * Math.cos(tc));
					}
					var dlng = Math.atan2(Math.sin(tc) * Math.sin(d) * Math.cos(lat), Math.cos(d) - Math.sin(lat) * Math.sin(y));
					var x = ((lng - dlng + Math.PI) % (2 * Math.PI)) - Math.PI;
					// MOD function
					var point = new google.maps.LatLng(parseFloat(y * (angl / Math.PI), 10), parseFloat(x * (angl / Math.PI), 10));
					plotPoints.push(point);
				}
			}

			this.getPoints = function() {
				if (plotPoints.length === 0) {
					var center = new google.maps.LatLng((pointStart.lat() + pointEnd.lat()) / 2, pointStart.lng() > pointEnd.lng() ? pointStart.lng() + options.straightLength : pointEnd.lng() + options.straightLength);
					
					var p1 = new google.maps.LatLng(pointStart.lat(), center.lng());
					var p2 = new google.maps.LatLng(pointEnd.lat(), center.lng());
					var radious = google.maps.geometry.spherical.computeDistanceBetween(p1, p2) / 3218;
					var viaZeroLng = (pointStart.lng() * pointEnd.lng()) < 0;

					plotPoints.push(pointStart);
					if (viaZeroLng && pointStart.lng() < 0) {
						plotPoints.push(new google.maps.LatLng(pointStart.lat(), 0));
					}
					
					//plotPoints.push(new google.maps.LatLng(pointStart.lat(), center.lng()));
					arcPoints(center, radious, pointEnd.lat() <= pointStart.lat());
					//plotPoints.push(new google.maps.LatLng(pointEnd.lat(), center.lng()));
					if (viaZeroLng && pointEnd.lng() < 0) {
						plotPoints.push(new google.maps.LatLng(pointEnd.lat(), 0));
					}
					plotPoints.push(pointEnd);
				}
				return plotPoints;
			};

			this.draw = function(map, pathIcons) {
				line = new google.maps.Polyline({
					path: this.getPoints(),
					icons: pathIcons,
					strokeOpacity: 0,
					geodesic: false,
					map: map
				});
			};

			this.animateIcon = function(lineSymbol) {
				var deferred = $q.defer();
				if(animationCompleted){
					return deferred.promise;
				}
				

				if (line === null) {
					deferred.reject('Polyline is not initiated.');
				}
				var icons = line.get('icons');
				icons.push({
					icon: lineSymbol,
					offset: '0%'
				});
				line.set('icons', icons);
				var count = 0;
				animObj = $interval(function() {
					count = (count + 1) % 200;

					//var icons = line.get('icons');
					if (count === 0) {
						$interval.cancel(animObj);
						animObj = null;
						icons.pop();
						deferred.resolve(options.attr);
					}
					else {
						icons[icons.length - 1].offset = (count / 2) + '%';
					}

					line.set('icons', icons);
				}, 20);
				return deferred.promise;
			};

			this.remove = function() {
				if (animObj !== null) {
					$interval.cancel(animObj);
					animObj = null;
				}
				if (line !== null) {
					line.setMap(null);
					line = null;
				}
			};
		}
		this.ArcPath = ArcPath;
  });