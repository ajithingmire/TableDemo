angular.module('animApp', ['ngRoute', 'ngAnimate']).
	config(function($routeProvider) {
		//$locationProvider.html5Mode(true);
		
		$routeProvider.when('/liquidity-management', {
			controller: 'LiquidityManagementCtrl',
			controllerAs: 'lm',
			templateUrl: 'app/views/lm-view.html'
		}).
		otherwise({ redirectTo: '/liquidity-management' });
	}).
	constant('appConfig', {
		mapIconBaseUri: '/images/map',
		iconBaseUri: '/images/icons'
	});