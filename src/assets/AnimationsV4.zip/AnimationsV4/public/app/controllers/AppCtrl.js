angular.module('animApp').
  controller('AppCtrl', function() {
	});