angular.module('animApp').
  controller('LiquidityManagementCtrl', function(AppService, GMapService, appConfig) {
		var self = this;
		var planeSVG = "m0,0h28l24,30h72l-44,-133h35l80,132h98c21,0 21,34 0,34l-98,0 -80,134h-35l43,-133h-71l-24,30h-28l15,-47";
		var destination = null,
			sources = [],
			markers = [],
			animationCompleted = false;
		
		function getMapIcon(icon) {
			return appConfig.mapIconBaseUri + '/' + icon;
		}

		function getIcon(icon) {
			return appConfig.iconBaseUri + '/' + icon;
		}

		var mapIcons = {
			P: {
				url: getMapIcon('icon-FAB22A.png'),
				scaledSize: new google.maps.Size(16, 16),
				anchor: new google.maps.Point(8, 8)
			},
			R: {
				url: getMapIcon('icon-FAB22A-C15519.png'),
				scaledSize: new google.maps.Size(16, 16),
				anchor: new google.maps.Point(8, 8)
			},
			PR: {
				url: getMapIcon('icon-FAB22A-626069.png'),
				scaledSize: new google.maps.Size(16, 16),
				anchor: new google.maps.Point(8, 8)
			},
			NR: {
				url: getMapIcon('icon-FAB22A-14649F.png'),
				scaledSize: new google.maps.Size(16, 16),
				anchor: new google.maps.Point(8, 8)
			},
			RA: {
				url: getMapIcon('icon-RA.png'),
				scaledSize: new google.maps.Size(16, 16),
				anchor: new google.maps.Point(8, 8)
			},
			NRA: {
				url: getMapIcon('icon-NRA.png'),
				scaledSize: new google.maps.Size(16, 16),
				anchor: new google.maps.Point(8, 8)
			},
			ELA: {
				url: getMapIcon('icon-ELA.png'),
				scaledSize: new google.maps.Size(16, 16),
				anchor: new google.maps.Point(8, 8)
			},
			TB: {
				url: getMapIcon('icon-line-FFFFFF.png'),
				scaledSize: new google.maps.Size(16, 16),
				anchor: new google.maps.Point(8, 8)
			},
			MFT: {
				url: getMapIcon('icon-line-75BDDE.png'),
				scaledSize: new google.maps.Size(16, 16),
				anchor: new google.maps.Point(8, 8)
			},
			RS: {
				url: getMapIcon('icon-line-dashed.png'),
				scaledSize: new google.maps.Size(16, 16),
				anchor: new google.maps.Point(8, 8)
			},
			IO: {
				url: getMapIcon('icon-IO.png'),
				scaledSize: new google.maps.Size(16, 16),
				anchor: new google.maps.Point(8, 8)
			},
			NP: {
				url: getMapIcon('icon-NP.png'),
				scaledSize: new google.maps.Size(16, 16),
				anchor: new google.maps.Point(8, 8)
			}
		};

		self.regions = [];
		self.regionBoxHeight = 0;
		self.legendOpened = false;
		self.iconStyles = {};
		for (var k in mapIcons) {
			self.iconStyles[k] = {
				'background-image': 'url(\'' + mapIcons[k].url + '\')'
			};
		}

    var map = new google.maps.Map(document.getElementById('map-view'), {
			zoom: 4,
      center: { lat: 0, lng: 0 },
			mapTypeId: google.maps.MapTypeId.SATELLITE,
			disableDefaultUI: true,
			disableDoubleClickZoom: true,
			scrollwheel: false
		});

		map.addListener('bounds_changed', function() {
			//map.panTo(map.getCenter());
			
		});

		map.addListener('zoom_changed', function() {
			//map.panTo(map.getCenter());
			markers.forEach(function(marker) {
				if (marker.arc) {
					marker.arc.remove();
				}
			});
			sources = [];
			markers = [];
			destination = null;
		});

		function clearMarkers() {
			markers.forEach(function(marker) {
				if (marker.arc) {
					marker.arc.remove();
				}
				marker.remove();
			});
			markers = [];
		}

		function gmarkersLoaded(sources, destination) {
			//map.fitBounds(bounds);
			//bounds.extend(sources);
			//bounds.extend(destination);
			if (destination !== null) {
				sources.forEach(function(source) {
					//console.log(source.getPosition().lat(), source.getPosition().lng());
					//console.log(source.newPosition);
					var arc = new GMapService.ArcPath(source.newPosition, destination.newPosition, {
						straightLength: 10,
						startPointOffset: new google.maps.Point(0, 0),
						endPointOffset: new google.maps.Point(0, 0),
						attr: {
							accBalM: source.accBalM
						}
					}, animationCompleted);
					var iconLine, iconLineCap;
					
					/*var lineSymbol = {
						path: 'M 194.65625 69.375 L 194.65625 101.875 C 181.50525 101.875 122.34375 118.62875 122.34375 172.34375 C 122.34375 220.12875 165.036 233.13724 194.625 237.40625 L 194.65625 291.40625 C 173.05125 285.23925 169.125 268.61599 166.125 254.875 L 118.6875 254.875 C 121.6235 308.616 168.82425 333.61025 194.65625 337.40625 L 194.65625 370.46875 L 239.75 370.46875 L 239.75 337.90625 C 275.445 336.00825 317.71876 305.18449 317.71875 262.9375 C 317.71875 214.5515 275.61 200.817 239.75 197.125 L 239.75 147.625 C 253.86 148.625 264.8705 162.625 266.0625 176.875 L 313.03125 176.875 C 313.03125 128.875 269.36025 103.625 239.28125 101.875 L 239.28125 69.375 L 194.65625 69.375 z M 194.90625 148.09375 L 194.90625 189.125 C 163.11824 188.625 162.50025 153.78675 194.90625 148.09375 z M 240.28125 245.125 C 279.61824 246.125 283.97475 285.37925 240.21875 291.65625 L 240.28125 245.125 z',
						scale: 0.05,
						strokeColor: '#FFFFFF',
						fillColor: '#FFFFFF',
						strokeOpacity: 1,
						fillOpacity: 1,
						rotation: 90,
						anchor: new google.maps.Point(230, 230)
					};*/
					/*var lineSymbol = {
						path: google.maps.SymbolPath.CIRCLE,
						scale: 4,
						strokeColor: '#393',
						strokeOpacity: 1,
						fillOpacity: 1,
					};
					planeSVG = '';*/

					var lineSymbol = {
						path: planeSVG,
						scale: 0.06,
						strokeColor: '#FFFFFF',
						fillColor: '#FFFFFF',
						strokeOpacity: 1,
						fillOpacity: 1,
						rotation: -90,
						anchor: new google.maps.Point(230, 50)
					};

					//marker.manualTransfer = country.manualTransfer;
					//marker.targetBalancing = country.targetBalancing;

					var icons = [];
					if (source.targetBalancing.enabled) {
						iconLine = {
							icon: {
								path: 'M0,-1 0,1',
								strokeOpacity: 1,
								scale: 1.5,
								strokeWeight: 1.5,
								strokeColor: '#FFFFFF'
							},
							offset: '0',
							repeat: source.targetBalancing.restricted ? '7px' : '1px'
						};
						iconLineCap = {
							icon: {
								path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
								strokeOpacity: 1,
								scale: 2,
								strokeWeight: 2,
								strokeColor: '#FFFFFF',
								fillColor: '#FFFFFF',
								fillOpacity: 1
							},
							offset: '100%'
						};
						
						icons.push(iconLine);
						icons.push(iconLineCap);
					}

					if (source.manualTransfer.enabled) {
						iconLine = {
							icon: {
								path: 'M0,-1 0,1',
								strokeOpacity: 1,
								scale: 1.5,
								strokeWeight: 1.5,
								strokeColor: '#75BDDE'
							},
							offset: '0',
							repeat: source.manualTransfer.restricted ? '7px' : '1px'
						};
						iconLineCap = {
							icon: {
								path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
								strokeOpacity: 1,
								scale: 2,
								strokeWeight: 2,
								strokeColor: '#75BDDE',
								fillColor: '#75BDDE',
								fillOpacity: 1
							},
							offset: '100%'
						};
						icons.push(iconLine);
						icons.push(iconLineCap);
					}

					//var icons = [iconLine, iconLineCap];
					arc.draw(map, icons);
					//arc.getPoints().forEach(function(pt) {
						//bounds.extend(pt);
					//});
					arc.animateIcon(lineSymbol).then(function(attr) {
						destination.accBalM += attr.accBalM;
						destination.getContainer().find('.gmap-marker-label .acc-bal').text(destination.accBalM.toFixed(1) + ' M');
						animationCompleted = true;
					});
					source.arc = arc;
				});
			}
			//map.fitBounds(bounds);
		}

		function setRegionMenu(regions, selected) {
			self.regions = [];
			self.regionBoxHeight = 0;
			self.regionMenuLines = [];
			var isPrevSelected = false;
			var iconWidth = 24;
			var iconHeight = 24;
			var selectedItemX = 30;
			var rowHeight = 30;

			var xPos = 0;
			var yPos = 0;

			self.regionMenuLines.push({
				x1: xPos,
				y1: yPos + 16,
				x2: xPos + 20,
				y2: yPos + 16
			});
			xPos += 20;
			yPos += 16;
			regions.forEach(function(region, i) {
				//console.log('Iteration: ', i);
				var line;
				var ratio = (i === 0 ? 0.6 : 1);

				line = {
					x1: xPos,
					y1: yPos,
					x2: xPos,
					y2: yPos + (ratio * rowHeight)
				};
				//console.log('Line: ', line.y1, ', ', line.y2);

				region.draw = {
					icon: {
						x: xPos - (iconWidth * 0.5),
						//y: yPos + ((rowHeight * ratio) - iconHeight) + (iconHeight / 2),
						y: yPos + (rowHeight * ratio) - (iconHeight * 0.5),
						href: getIcon('/regions/' + region.id + '.png'),
						width: iconWidth,
						height: iconHeight
					},
					text: {
						x: xPos + (iconWidth * 0.5) + 10,
						//y: yPos + (rowHeight * ratio) + ((rowHeight * ratio) - (iconHeight * ratio))
						y: yPos + (((2 * rowHeight) - iconHeight) * ratio)
					}
				};
				//console.log('Icon: ', region.draw.icon.y);
				//console.log('Text: ', region.draw.text.y);

				if (isPrevSelected) {
					line.x1 += selectedItemX;

					isPrevSelected = false;
				}
				region.draw.text.class = '';

				if (selected !== null && region.id === selected.id) {
					region.draw.icon.x += selectedItemX;
					region.draw.text.x += selectedItemX;
					region.draw.text.class += 'selected';
					line.x2 += selectedItemX;

					isPrevSelected = true;
				}

				self.regions.push(region);
				self.regionMenuLines.push(line);
				yPos += ratio * rowHeight;
			});
			if (self.regions.length > 0) {
				var lastIcon = self.regions[self.regions.length - 1].draw.icon;
				self.regionBoxHeight = lastIcon.y + lastIcon.height + 8;
			}
		}

    AppService.getRegions().then(function(response) {
			setRegionMenu(response.data, null);
			
      //console.log('JSON Data...', response.data);
    }).catch(function() {
      console.error('Error Service.');
    });
		
		self.zoom = function(val) {
			var newZoom = map.getZoom() + val;
			if (newZoom > 1 && newZoom < 10) {
				map.setZoom(newZoom);
			}
		};

		self.onRegionClicked = function(region) {
			var bounds = new google.maps.LatLngBounds();
			setRegionMenu(self.regions, region);
			clearMarkers();
			animationCompleted = false;
			
			region.countries.forEach(function(country) {
				var position = new google.maps.LatLng(country.lat, country.lng);

				bounds.extend(position);

				var countryClass = '';
				if (country.isCenter) {
					countryClass += ' gmap-big';
				}
				var marker = new GMapService.GMarker({
					position: position,
					icon: mapIcons[country.regulationType],
					clickable: false,
					map: map
				},
				'<div class="gmap-marker-label' + countryClass + '">' +
					'<span class="country">' + country.name + '</span>' +
					'<span class="acc-bal">' + country.accBalM.toFixed(1) + ' M</span>' +
				'</div>');
				marker.linePath = null;
				marker.accBalM = country.accBalM;
				marker.manualTransfer = country.manualTransfer;
				marker.targetBalancing = country.targetBalancing;

				marker.addListener('gmarker_loaded', function(div) {
					var proj = this.getProjection();
					var pixelPosition = proj.fromLatLngToDivPixel(this.getMarker().getPosition());
					//console.log('Width: ', div.outerWidth());
					pixelPosition.x += div.outerWidth() + 14;
					this.newPosition = proj.fromDivPixelToLatLng(pixelPosition);
					this.country = country;
					if (!country.restricted) {
						if (country.isCenter) {
							destination = this;
						}
						else {
							sources.push(this);
							//console.log('1w2');
						}
					}
					
					markers.push(this);

					if (markers.length === region.countries.length) {
						//console.log(22222);
						gmarkersLoaded(sources, destination);
						//console.log('Length: ', markers.length);
					}
				});
			});
			map.fitBounds(bounds);
		};

		self.onLegendButtonClicked = function() {
			self.legendOpened = !self.legendOpened;
			//console.log(self.legendOpened);
		};
  });