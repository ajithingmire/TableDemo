let fs = require('fs');
let xml2js = require('xml2js');

module.exports = function() {
  var structure = null;

  function getObject() {
    return new Promise(function(accept, reject) {
      if (structure == null) {
        var parser = new xml2js.Parser();
        fs.readFile(`${__dirname}/AccountStructure.xml`, function(err, data) {
          if (err) {
            reject(err);
            return;
          }
          parser.parseString(data, function (err, result) {
            if (err) {
              reject(err);
              return;
            }
            structure = result.AccountStructure;
            accept(structure);
          });
        });
        return;
      }
      accept(structure);
    });
  }

  this.getRegions = function() {
		var self = this;
    return new Promise(function(accept, reject) {
      getObject().then(function(accs) {
        var regions = [];
				var countries = [];
				var accountBalance = 0.00;
        regions.push({
          id: '0',
          name: 'Global',
          symbol: 'Global',
					accBal: 0.00,
					accBalM: 0.00,
					countries: []
        });
        accs.Region.forEach(function(r) {
					var c = self.getCountries(r);
					accountBalance += c.accountBalance;
          var region = {
          	id: r.$.id,
						name: r.$.name,
						symbol: r.$.symbol,
						accBal: c.accountBalance,
						accBalM: self.toMillion(c.accountBalance),
						countries: c.countries
          };
          regions.push(region);
          c.countries.forEach(function(country) {
            if (['regional', 'global'].indexOf(country.isConcentrationCenter) > -1) {
              var cObj = Object.assign({}, country);
              cObj.isCenter = country.isConcentrationCenter == 'global';
              cObj.accBal = region.accBal;
              cObj.accBalM = region.accBalM;

              countries.push(cObj);
            }
          });
        });
        regions[0].countries = countries;
				regions[0].accBal = accountBalance;
        regions[0].accBalM = self.toMillion(accountBalance);
        //regions.pop();
        //regions.pop();

        accept(regions);
      }).catch(reject);
    });
  }

	this.getCountries = function(region) {
		var self = this;
		var countries = [];
		var accountBalance = 0.00;
		region.Country.forEach(function(c) {
			var accountInfo = self.getAccounts(c);
			accountBalance += accountInfo.totalBalance;
      var country = {
				id: parseInt(c.$.id),
        name: c.$.name,
        symbol: c.$.symbol,
        regulationType: c.$.RegulationType,
        isConcentrationCenter: c.$.isConcentrationCenter,
				lat: parseFloat(c.$.lat),
				lng: parseFloat(c.$.long),
        accBal: accountInfo.totalBalance,
				accBalM: self.toMillion(accountInfo.totalBalance),
        isCenter: ['regional', 'global'].indexOf(c.$.isConcentrationCenter) > -1,
        restricted: ['R'].indexOf(c.$.RegulationType) > -1,
        accounts: accountInfo.accounts,
        manualTransfer: {
          enabled: ['PH', 'ID', 'NO', 'FI'].indexOf(c.$.symbol) > -1,
          restricted: ['PH', 'FI'].indexOf(c.$.symbol) > -1
        },
        targetBalancing: {
          enabled: ['PH'].indexOf(c.$.symbol) === -1,
          restricted: ['KR', 'FR'].indexOf(c.$.symbol) === -1
        }
			};

			countries.push(country);
		});

		return {accountBalance: accountBalance, countries: countries};
	}

  this.getAccounts = function(country) {
    var self = this;
    var accounts = [];
    var accBal = 0.00;
		country.City.forEach(function(city) {
			city.Account.forEach(function(a) {
        var account = {
          id: self.toNumber(a.$.id, parseInt),
          name: a.$.name,
          conOfIncorp: self.toNumber(a.$.conOfIncorp, parseInt),
          isHeaderAccount: (a.$.isHeaderAccount == 'true'),
          isResident: (a.$.isResident == 'true'),
          category: self.toNumber(a.$.category, parseInt),
          iscio: (a.$.iscio == 'true'),
          isCCCLaccount: (a.$.IsCCCLaccount == 'true'),
          accountType: a.AccountType[0],
          accountPurpose: a.AccountPurpose[0],
          originalAccountBalance: self.toNumber(a.OriginalAccountBalance[0], parseFloat),
          modifiedAccountBalance: self.toNumber(a.ModifiedAccountBalance[0], parseFloat),
          averageOverdraftRequirement: self.toNumber(a.AverageOverdraftRequirement[0], parseFloat),
          legalEntity: {
            id: self.toNumber(a.LegalEntity[0].$.id, parseInt),
            name: a.LegalEntity[0].$.name
          },
          sweepInfo: {
            type: a.SweepInfo[0].Type[0],
            isCrossBorder: a.SweepInfo[0].IsCrossBorder[0] == 'true',
            amount: self.toNumber(a.SweepInfo[0].Amount[0], parseFloat),
            sweepAccount: self.toNumber(a.SweepInfo[0].SweepAccount[0], parseFloat),
            product: a.SweepInfo[0].Product[0],
            poolType: a.SweepInfo[0].PoolType[0],
            sweepResType: a.SweepInfo[0].SweepResType[0],
            isMCNPHeader: a.SweepInfo[0].IsMCNPHeader[0] == 'true',
            isSCNPHeader: a.SweepInfo[0].IsSCNPHeader[0] == 'true'
          },
          currency: {
            id: self.toNumber(a.Currency[0].$.id, parseInt),
            name: a.Currency[0].$.name
          },
          benefitAnalysisInfo: {
            interestType: a.BenefitAnalysisInfo[0].$.interestType,
            accountRelation: a.BenefitAnalysisInfo[0].$.accountRelation
          }
        };
        accBal += account.modifiedAccountBalance;
        accounts.push(account);
			});
		});
    return { totalBalance: accBal, accounts: accounts };
	}

  this.findCountries = function(regionId) {
    return new Promise(function(accept, reject) {
      getObject().then(function(accs) {
        var regions = [];
        var countries = [];
        accs.Region.forEach(function(r) {
          if (regionId == 0) {
            regions.push(r);
          }
          else {
            if (regionId == r.$.id) {
              regions.push(r);
              return false;
            }
          }
        });

        regions.forEach(function(r) {
          r.Country.forEach(function(c) {
            countries.push(c);
          });
        });
        
        accept(countries);
      }).catch(reject);
    });
  }

  this.toMillion = function(amount) {
    amount = parseFloat(amount);
    var mValue = +(amount / 1000000).toFixed(1);

    return mValue;
  }

  this.toNumber = function(str, formatter) {
    return isNaN(str) ? 0 : formatter(str);
  }
}
