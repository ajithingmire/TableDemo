let express = require('express');
let bodyParser = require('body-parser');
let AccountStructure = require('./AccountStructure');

let app = express();
let account = new AccountStructure();

app.use(express.static('public'));

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// parse application/json
app.use(bodyParser.json());

app.get('/api/regions', function(req, res) {
  account.getRegions().then(function(regions) {
    res.send(regions);
  }).catch(function(e) {
    console.log(e);
    res.status(500).send('API Error.');
  });
});

app.get('/api/region/:regionId/countries', function(req, res) {
  account.getCountries(req.params.regionId).then(function(rCountries) {
    var countries = [];
    rCountries.forEach(function(country) {
      //console.log(country);
      var accBal = 0.00;
      country.City.forEach(function(city) {
        city.Account.forEach(function(account) {
          accBal += parseFloat(account.ModifiedAccountBalance[0])
        });
      });
      countries.push({
        id: parseInt(country.$.id),
        name: country.$.name,
        symbol: country.$.symbol,
        regulationType: country.$.RegulationType,
        isConcentrationCenter: country.$.isConcentrationCenter,
        lat: country.$.lat,
        lng: country.$.lng,
        accountBalance: (accBal / 1000000).toFixed(1)
      });
    });
    res.send(countries);
  }).catch(function() {
    res.status(500).send('API Error.');
  });
});

app.listen(3000, function() {
  console.log('Express running in 3000 port.');
});
