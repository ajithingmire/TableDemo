module.exports = function(grunt) {
	grunt.initConfig({
		pkg: grunt.file.readJSON('package.json'),
		svg2png: {
			all: {
				// specify files in array format with multiple src-dest mapping 
				files: [
					// rasterize all SVG files in "img" and its subdirectories to "img/png" 
					{ cwd: 'public/images/svg/', src: ['**/*.svg'], dest: 'public/images/map/' }
				]
			}
		},
		concat: {
			options: {
				separator: '',
			},
			js: {
				src: [
					'public/js/jquery-1.12.4.min.js',
					'public/js/angular.min.js',
					'public/js/angular-animate.min.js',
					'public/js/angular-route.min.js',
					'public/js/bootstrap.min.js',

					'public/app/app.js',
					'public/app/services/GMapService.js',
					'public/app/services/AppService.js',
					'public/app/controllers/LiquidityManagementCtrl.js',
					'public/app/controllers/AppCtrl.js'
				],
				dest: 'cache/js/build.js',
			},
			css: {
				src: [
					'public/css/bootstrap.min.css',
					'public/css/app.css'
				],
				dest: 'cache/css/build.css'
			},
		},
		cssmin: {
			options: {
				shorthandCompacting: false,
				roundingPrecision: -1
			},
			dist: {
				files: {
					'public/css/build.min.css': ['cache/css/build.css']
				}
			}
		},
		uglify: {
			options: {
				mangle: false,
				preserveComments: false
			},
			dist: {
				files: {
					'public/js/build.min.js': ['cache/js/build.js']
				}
			}
		},
		replace: {
			dist: {
				options: {
					patterns: [{
						match: 'version',
						replacement: '<%= new Date().getTime() %>'
					}]
				},
				files: [
					{expand: true, flatten: true, src: ['public/app.html'], dest: 'cache/'}
				]
			}
		},
		htmlmin: {
			dist: {
				options: {
					removeComments: true,
					collapseWhitespace: true
				},
				files: {
					'public/index.html': 'cache/app.html'
				}
			}
		},
		jshint: {
			options: {
				curly: true,
				eqeqeq: true,
				eqnull: true,
				browser: true,
				unused: true,
				latedef: true,
				undef: true,
				nocomma: true,
				nonbsp: true,
				devel: true,
				globals: {
					jQuery: true,
					angular: true,
					google: true,
					$: true
				},
			},
			source: [
				'public/app/**/*.js'
			]
		}
	});

	grunt.loadNpmTasks('grunt-svg2png');
	grunt.loadNpmTasks('grunt-contrib-concat');
	grunt.loadNpmTasks('grunt-contrib-uglify');
	grunt.loadNpmTasks('grunt-contrib-jshint');
	grunt.loadNpmTasks('grunt-contrib-cssmin');
	grunt.loadNpmTasks('grunt-contrib-htmlmin');
	grunt.loadNpmTasks('grunt-replace');

	grunt.registerTask('buildjs', [
		'jshint:source',
		'concat:js',
		'uglify:dist'
	]);
	grunt.registerTask('buildcss', [
		'concat:css',
		'cssmin:dist'
	]);
	grunt.registerTask('buildhtml', [
		'replace:dist',
		'htmlmin:dist'
	]);
	grunt.registerTask('build', [
		'buildjs',
		'buildcss',
		'buildhtml'
	]);
	grunt.registerTask('buildall', ['svg2png', 'build']);
}